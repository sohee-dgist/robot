﻿namespace WindowsFormsApp4
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.button1 = new System.Windows.Forms.Button();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label15 = new System.Windows.Forms.Label();
            this.richTextBox36 = new System.Windows.Forms.RichTextBox();
            this.richTextBox41 = new System.Windows.Forms.RichTextBox();
            this.richTextBox51 = new System.Windows.Forms.RichTextBox();
            this.richTextBox42 = new System.Windows.Forms.RichTextBox();
            this.richTextBox2 = new System.Windows.Forms.RichTextBox();
            this.richTextBox43 = new System.Windows.Forms.RichTextBox();
            this.richTextBox4 = new System.Windows.Forms.RichTextBox();
            this.richTextBox44 = new System.Windows.Forms.RichTextBox();
            this.richTextBox3 = new System.Windows.Forms.RichTextBox();
            this.richTextBox45 = new System.Windows.Forms.RichTextBox();
            this.richTextBox7 = new System.Windows.Forms.RichTextBox();
            this.richTextBox46 = new System.Windows.Forms.RichTextBox();
            this.richTextBox5 = new System.Windows.Forms.RichTextBox();
            this.richTextBox47 = new System.Windows.Forms.RichTextBox();
            this.richTextBox10 = new System.Windows.Forms.RichTextBox();
            this.richTextBox48 = new System.Windows.Forms.RichTextBox();
            this.richTextBox6 = new System.Windows.Forms.RichTextBox();
            this.richTextBox49 = new System.Windows.Forms.RichTextBox();
            this.richTextBox13 = new System.Windows.Forms.RichTextBox();
            this.richTextBox50 = new System.Windows.Forms.RichTextBox();
            this.richTextBox8 = new System.Windows.Forms.RichTextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.richTextBox16 = new System.Windows.Forms.RichTextBox();
            this.richTextBox31 = new System.Windows.Forms.RichTextBox();
            this.richTextBox9 = new System.Windows.Forms.RichTextBox();
            this.richTextBox32 = new System.Windows.Forms.RichTextBox();
            this.richTextBox19 = new System.Windows.Forms.RichTextBox();
            this.richTextBox33 = new System.Windows.Forms.RichTextBox();
            this.richTextBox11 = new System.Windows.Forms.RichTextBox();
            this.richTextBox34 = new System.Windows.Forms.RichTextBox();
            this.richTextBox22 = new System.Windows.Forms.RichTextBox();
            this.richTextBox35 = new System.Windows.Forms.RichTextBox();
            this.richTextBox12 = new System.Windows.Forms.RichTextBox();
            this.richTextBox25 = new System.Windows.Forms.RichTextBox();
            this.richTextBox37 = new System.Windows.Forms.RichTextBox();
            this.richTextBox14 = new System.Windows.Forms.RichTextBox();
            this.richTextBox38 = new System.Windows.Forms.RichTextBox();
            this.richTextBox28 = new System.Windows.Forms.RichTextBox();
            this.richTextBox39 = new System.Windows.Forms.RichTextBox();
            this.richTextBox15 = new System.Windows.Forms.RichTextBox();
            this.richTextBox40 = new System.Windows.Forms.RichTextBox();
            this.richTextBox17 = new System.Windows.Forms.RichTextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.richTextBox18 = new System.Windows.Forms.RichTextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.richTextBox20 = new System.Windows.Forms.RichTextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.richTextBox21 = new System.Windows.Forms.RichTextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.richTextBox23 = new System.Windows.Forms.RichTextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.richTextBox24 = new System.Windows.Forms.RichTextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.richTextBox26 = new System.Windows.Forms.RichTextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.richTextBox27 = new System.Windows.Forms.RichTextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.richTextBox29 = new System.Windows.Forms.RichTextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.richTextBox30 = new System.Windows.Forms.RichTextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label16 = new System.Windows.Forms.Label();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.richTextBox52 = new System.Windows.Forms.RichTextBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.richTextBox53 = new System.Windows.Forms.RichTextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.richTextBox54 = new System.Windows.Forms.RichTextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.richTextBox55 = new System.Windows.Forms.RichTextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.richTextBox56 = new System.Windows.Forms.RichTextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.richTextBox57 = new System.Windows.Forms.RichTextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.richTextBox58 = new System.Windows.Forms.RichTextBox();
            this.richTextBox101 = new System.Windows.Forms.RichTextBox();
            this.richTextBox59 = new System.Windows.Forms.RichTextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.richTextBox60 = new System.Windows.Forms.RichTextBox();
            this.richTextBox100 = new System.Windows.Forms.RichTextBox();
            this.richTextBox61 = new System.Windows.Forms.RichTextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.richTextBox62 = new System.Windows.Forms.RichTextBox();
            this.richTextBox99 = new System.Windows.Forms.RichTextBox();
            this.richTextBox63 = new System.Windows.Forms.RichTextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.richTextBox64 = new System.Windows.Forms.RichTextBox();
            this.richTextBox98 = new System.Windows.Forms.RichTextBox();
            this.richTextBox65 = new System.Windows.Forms.RichTextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.richTextBox66 = new System.Windows.Forms.RichTextBox();
            this.richTextBox97 = new System.Windows.Forms.RichTextBox();
            this.richTextBox67 = new System.Windows.Forms.RichTextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.richTextBox68 = new System.Windows.Forms.RichTextBox();
            this.richTextBox96 = new System.Windows.Forms.RichTextBox();
            this.richTextBox69 = new System.Windows.Forms.RichTextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.richTextBox70 = new System.Windows.Forms.RichTextBox();
            this.richTextBox95 = new System.Windows.Forms.RichTextBox();
            this.richTextBox71 = new System.Windows.Forms.RichTextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.richTextBox72 = new System.Windows.Forms.RichTextBox();
            this.richTextBox94 = new System.Windows.Forms.RichTextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.richTextBox73 = new System.Windows.Forms.RichTextBox();
            this.richTextBox93 = new System.Windows.Forms.RichTextBox();
            this.richTextBox74 = new System.Windows.Forms.RichTextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.richTextBox75 = new System.Windows.Forms.RichTextBox();
            this.richTextBox92 = new System.Windows.Forms.RichTextBox();
            this.richTextBox76 = new System.Windows.Forms.RichTextBox();
            this.richTextBox91 = new System.Windows.Forms.RichTextBox();
            this.richTextBox77 = new System.Windows.Forms.RichTextBox();
            this.richTextBox90 = new System.Windows.Forms.RichTextBox();
            this.richTextBox78 = new System.Windows.Forms.RichTextBox();
            this.richTextBox89 = new System.Windows.Forms.RichTextBox();
            this.richTextBox79 = new System.Windows.Forms.RichTextBox();
            this.richTextBox88 = new System.Windows.Forms.RichTextBox();
            this.richTextBox80 = new System.Windows.Forms.RichTextBox();
            this.richTextBox87 = new System.Windows.Forms.RichTextBox();
            this.richTextBox81 = new System.Windows.Forms.RichTextBox();
            this.richTextBox86 = new System.Windows.Forms.RichTextBox();
            this.richTextBox82 = new System.Windows.Forms.RichTextBox();
            this.richTextBox85 = new System.Windows.Forms.RichTextBox();
            this.richTextBox83 = new System.Windows.Forms.RichTextBox();
            this.richTextBox84 = new System.Windows.Forms.RichTextBox();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(12, 39);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "시작";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(12, 93);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(386, 176);
            this.richTextBox1.TabIndex = 3;
            this.richTextBox1.Text = "";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(14, 285);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(384, 21);
            this.textBox1.TabIndex = 4;
            this.textBox1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox1_KeyDown);
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 12;
            this.listBox1.Location = new System.Drawing.Point(12, 326);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(386, 88);
            this.listBox1.TabIndex = 5;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(14, 68);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(142, 16);
            this.checkBox1.TabIndex = 6;
            this.checkBox1.Text = "메세지를 표시할까요?";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.richTextBox1);
            this.groupBox1.Controls.Add(this.checkBox1);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.listBox1);
            this.groupBox1.Controls.Add(this.textBox1);
            this.groupBox1.Location = new System.Drawing.Point(14, 23);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(414, 435);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "서버";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.richTextBox36);
            this.groupBox2.Controls.Add(this.richTextBox41);
            this.groupBox2.Controls.Add(this.richTextBox51);
            this.groupBox2.Controls.Add(this.richTextBox42);
            this.groupBox2.Controls.Add(this.richTextBox2);
            this.groupBox2.Controls.Add(this.richTextBox43);
            this.groupBox2.Controls.Add(this.richTextBox4);
            this.groupBox2.Controls.Add(this.richTextBox44);
            this.groupBox2.Controls.Add(this.richTextBox3);
            this.groupBox2.Controls.Add(this.richTextBox45);
            this.groupBox2.Controls.Add(this.richTextBox7);
            this.groupBox2.Controls.Add(this.richTextBox46);
            this.groupBox2.Controls.Add(this.richTextBox5);
            this.groupBox2.Controls.Add(this.richTextBox47);
            this.groupBox2.Controls.Add(this.richTextBox10);
            this.groupBox2.Controls.Add(this.richTextBox48);
            this.groupBox2.Controls.Add(this.richTextBox6);
            this.groupBox2.Controls.Add(this.richTextBox49);
            this.groupBox2.Controls.Add(this.richTextBox13);
            this.groupBox2.Controls.Add(this.richTextBox50);
            this.groupBox2.Controls.Add(this.richTextBox8);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.richTextBox16);
            this.groupBox2.Controls.Add(this.richTextBox31);
            this.groupBox2.Controls.Add(this.richTextBox9);
            this.groupBox2.Controls.Add(this.richTextBox32);
            this.groupBox2.Controls.Add(this.richTextBox19);
            this.groupBox2.Controls.Add(this.richTextBox33);
            this.groupBox2.Controls.Add(this.richTextBox11);
            this.groupBox2.Controls.Add(this.richTextBox34);
            this.groupBox2.Controls.Add(this.richTextBox22);
            this.groupBox2.Controls.Add(this.richTextBox35);
            this.groupBox2.Controls.Add(this.richTextBox12);
            this.groupBox2.Controls.Add(this.richTextBox25);
            this.groupBox2.Controls.Add(this.richTextBox37);
            this.groupBox2.Controls.Add(this.richTextBox14);
            this.groupBox2.Controls.Add(this.richTextBox38);
            this.groupBox2.Controls.Add(this.richTextBox28);
            this.groupBox2.Controls.Add(this.richTextBox39);
            this.groupBox2.Controls.Add(this.richTextBox15);
            this.groupBox2.Controls.Add(this.richTextBox40);
            this.groupBox2.Controls.Add(this.richTextBox17);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.richTextBox18);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.richTextBox20);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.richTextBox21);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.richTextBox23);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.richTextBox24);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.richTextBox26);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.richTextBox27);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.richTextBox29);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.richTextBox30);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Location = new System.Drawing.Point(463, 23);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(593, 435);
            this.groupBox2.TabIndex = 8;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "로봇 상태";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(457, 53);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(61, 12);
            this.label15.TabIndex = 98;
            this.label15.Text = "Position y";
            // 
            // richTextBox36
            // 
            this.richTextBox36.Location = new System.Drawing.Point(370, 196);
            this.richTextBox36.Name = "richTextBox36";
            this.richTextBox36.Size = new System.Drawing.Size(75, 26);
            this.richTextBox36.TabIndex = 82;
            this.richTextBox36.Text = "";
            // 
            // richTextBox41
            // 
            this.richTextBox41.Location = new System.Drawing.Point(451, 356);
            this.richTextBox41.Name = "richTextBox41";
            this.richTextBox41.Size = new System.Drawing.Size(75, 26);
            this.richTextBox41.TabIndex = 88;
            this.richTextBox41.Text = "";
            // 
            // richTextBox51
            // 
            this.richTextBox51.Location = new System.Drawing.Point(127, 68);
            this.richTextBox51.Name = "richTextBox51";
            this.richTextBox51.Size = new System.Drawing.Size(75, 26);
            this.richTextBox51.TabIndex = 34;
            this.richTextBox51.Text = "";
            // 
            // richTextBox42
            // 
            this.richTextBox42.Location = new System.Drawing.Point(451, 324);
            this.richTextBox42.Name = "richTextBox42";
            this.richTextBox42.Size = new System.Drawing.Size(75, 26);
            this.richTextBox42.TabIndex = 89;
            this.richTextBox42.Text = "";
            // 
            // richTextBox2
            // 
            this.richTextBox2.Location = new System.Drawing.Point(208, 68);
            this.richTextBox2.Name = "richTextBox2";
            this.richTextBox2.Size = new System.Drawing.Size(75, 26);
            this.richTextBox2.TabIndex = 53;
            this.richTextBox2.Text = "";
            // 
            // richTextBox43
            // 
            this.richTextBox43.Location = new System.Drawing.Point(451, 292);
            this.richTextBox43.Name = "richTextBox43";
            this.richTextBox43.Size = new System.Drawing.Size(75, 26);
            this.richTextBox43.TabIndex = 90;
            this.richTextBox43.Text = "";
            // 
            // richTextBox4
            // 
            this.richTextBox4.Location = new System.Drawing.Point(127, 100);
            this.richTextBox4.Name = "richTextBox4";
            this.richTextBox4.Size = new System.Drawing.Size(75, 26);
            this.richTextBox4.TabIndex = 43;
            this.richTextBox4.Text = "";
            // 
            // richTextBox44
            // 
            this.richTextBox44.Location = new System.Drawing.Point(451, 260);
            this.richTextBox44.Name = "richTextBox44";
            this.richTextBox44.Size = new System.Drawing.Size(75, 26);
            this.richTextBox44.TabIndex = 91;
            this.richTextBox44.Text = "";
            // 
            // richTextBox3
            // 
            this.richTextBox3.Location = new System.Drawing.Point(289, 68);
            this.richTextBox3.Name = "richTextBox3";
            this.richTextBox3.Size = new System.Drawing.Size(75, 26);
            this.richTextBox3.TabIndex = 55;
            this.richTextBox3.Text = "";
            // 
            // richTextBox45
            // 
            this.richTextBox45.Location = new System.Drawing.Point(451, 228);
            this.richTextBox45.Name = "richTextBox45";
            this.richTextBox45.Size = new System.Drawing.Size(75, 26);
            this.richTextBox45.TabIndex = 92;
            this.richTextBox45.Text = "";
            // 
            // richTextBox7
            // 
            this.richTextBox7.Location = new System.Drawing.Point(127, 132);
            this.richTextBox7.Name = "richTextBox7";
            this.richTextBox7.Size = new System.Drawing.Size(75, 26);
            this.richTextBox7.TabIndex = 42;
            this.richTextBox7.Text = "";
            // 
            // richTextBox46
            // 
            this.richTextBox46.Location = new System.Drawing.Point(451, 196);
            this.richTextBox46.Name = "richTextBox46";
            this.richTextBox46.Size = new System.Drawing.Size(75, 26);
            this.richTextBox46.TabIndex = 93;
            this.richTextBox46.Text = "";
            // 
            // richTextBox5
            // 
            this.richTextBox5.Location = new System.Drawing.Point(208, 100);
            this.richTextBox5.Name = "richTextBox5";
            this.richTextBox5.Size = new System.Drawing.Size(75, 26);
            this.richTextBox5.TabIndex = 51;
            this.richTextBox5.Text = "";
            // 
            // richTextBox47
            // 
            this.richTextBox47.Location = new System.Drawing.Point(451, 164);
            this.richTextBox47.Name = "richTextBox47";
            this.richTextBox47.Size = new System.Drawing.Size(75, 26);
            this.richTextBox47.TabIndex = 94;
            this.richTextBox47.Text = "";
            // 
            // richTextBox10
            // 
            this.richTextBox10.Location = new System.Drawing.Point(127, 164);
            this.richTextBox10.Name = "richTextBox10";
            this.richTextBox10.Size = new System.Drawing.Size(75, 26);
            this.richTextBox10.TabIndex = 41;
            this.richTextBox10.Text = "";
            // 
            // richTextBox48
            // 
            this.richTextBox48.Location = new System.Drawing.Point(451, 132);
            this.richTextBox48.Name = "richTextBox48";
            this.richTextBox48.Size = new System.Drawing.Size(75, 26);
            this.richTextBox48.TabIndex = 95;
            this.richTextBox48.Text = "";
            // 
            // richTextBox6
            // 
            this.richTextBox6.Location = new System.Drawing.Point(289, 100);
            this.richTextBox6.Name = "richTextBox6";
            this.richTextBox6.Size = new System.Drawing.Size(75, 26);
            this.richTextBox6.TabIndex = 57;
            this.richTextBox6.Text = "";
            // 
            // richTextBox49
            // 
            this.richTextBox49.Location = new System.Drawing.Point(451, 100);
            this.richTextBox49.Name = "richTextBox49";
            this.richTextBox49.Size = new System.Drawing.Size(75, 26);
            this.richTextBox49.TabIndex = 96;
            this.richTextBox49.Text = "";
            // 
            // richTextBox13
            // 
            this.richTextBox13.Location = new System.Drawing.Point(127, 196);
            this.richTextBox13.Name = "richTextBox13";
            this.richTextBox13.Size = new System.Drawing.Size(75, 26);
            this.richTextBox13.TabIndex = 39;
            this.richTextBox13.Text = "";
            // 
            // richTextBox50
            // 
            this.richTextBox50.Location = new System.Drawing.Point(451, 68);
            this.richTextBox50.Name = "richTextBox50";
            this.richTextBox50.Size = new System.Drawing.Size(75, 26);
            this.richTextBox50.TabIndex = 97;
            this.richTextBox50.Text = "";
            // 
            // richTextBox8
            // 
            this.richTextBox8.Location = new System.Drawing.Point(208, 132);
            this.richTextBox8.Name = "richTextBox8";
            this.richTextBox8.Size = new System.Drawing.Size(75, 26);
            this.richTextBox8.TabIndex = 52;
            this.richTextBox8.Text = "";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(376, 53);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(61, 12);
            this.label14.TabIndex = 87;
            this.label14.Text = "Position x";
            // 
            // richTextBox16
            // 
            this.richTextBox16.Location = new System.Drawing.Point(127, 228);
            this.richTextBox16.Name = "richTextBox16";
            this.richTextBox16.Size = new System.Drawing.Size(75, 26);
            this.richTextBox16.TabIndex = 38;
            this.richTextBox16.Text = "";
            // 
            // richTextBox31
            // 
            this.richTextBox31.Location = new System.Drawing.Point(370, 356);
            this.richTextBox31.Name = "richTextBox31";
            this.richTextBox31.Size = new System.Drawing.Size(75, 26);
            this.richTextBox31.TabIndex = 77;
            this.richTextBox31.Text = "";
            // 
            // richTextBox9
            // 
            this.richTextBox9.Location = new System.Drawing.Point(289, 132);
            this.richTextBox9.Name = "richTextBox9";
            this.richTextBox9.Size = new System.Drawing.Size(75, 26);
            this.richTextBox9.TabIndex = 60;
            this.richTextBox9.Text = "";
            // 
            // richTextBox32
            // 
            this.richTextBox32.Location = new System.Drawing.Point(370, 324);
            this.richTextBox32.Name = "richTextBox32";
            this.richTextBox32.Size = new System.Drawing.Size(75, 26);
            this.richTextBox32.TabIndex = 78;
            this.richTextBox32.Text = "";
            // 
            // richTextBox19
            // 
            this.richTextBox19.Location = new System.Drawing.Point(127, 260);
            this.richTextBox19.Name = "richTextBox19";
            this.richTextBox19.Size = new System.Drawing.Size(75, 26);
            this.richTextBox19.TabIndex = 37;
            this.richTextBox19.Text = "";
            // 
            // richTextBox33
            // 
            this.richTextBox33.Location = new System.Drawing.Point(370, 292);
            this.richTextBox33.Name = "richTextBox33";
            this.richTextBox33.Size = new System.Drawing.Size(75, 26);
            this.richTextBox33.TabIndex = 79;
            this.richTextBox33.Text = "";
            // 
            // richTextBox11
            // 
            this.richTextBox11.Location = new System.Drawing.Point(208, 164);
            this.richTextBox11.Name = "richTextBox11";
            this.richTextBox11.Size = new System.Drawing.Size(75, 26);
            this.richTextBox11.TabIndex = 50;
            this.richTextBox11.Text = "";
            // 
            // richTextBox34
            // 
            this.richTextBox34.Location = new System.Drawing.Point(370, 260);
            this.richTextBox34.Name = "richTextBox34";
            this.richTextBox34.Size = new System.Drawing.Size(75, 26);
            this.richTextBox34.TabIndex = 80;
            this.richTextBox34.Text = "";
            // 
            // richTextBox22
            // 
            this.richTextBox22.Location = new System.Drawing.Point(127, 292);
            this.richTextBox22.Name = "richTextBox22";
            this.richTextBox22.Size = new System.Drawing.Size(75, 26);
            this.richTextBox22.TabIndex = 36;
            this.richTextBox22.Text = "";
            // 
            // richTextBox35
            // 
            this.richTextBox35.Location = new System.Drawing.Point(370, 228);
            this.richTextBox35.Name = "richTextBox35";
            this.richTextBox35.Size = new System.Drawing.Size(75, 26);
            this.richTextBox35.TabIndex = 81;
            this.richTextBox35.Text = "";
            // 
            // richTextBox12
            // 
            this.richTextBox12.Location = new System.Drawing.Point(289, 164);
            this.richTextBox12.Name = "richTextBox12";
            this.richTextBox12.Size = new System.Drawing.Size(75, 26);
            this.richTextBox12.TabIndex = 54;
            this.richTextBox12.Text = "";
            // 
            // richTextBox25
            // 
            this.richTextBox25.Location = new System.Drawing.Point(127, 324);
            this.richTextBox25.Name = "richTextBox25";
            this.richTextBox25.Size = new System.Drawing.Size(75, 26);
            this.richTextBox25.TabIndex = 40;
            this.richTextBox25.Text = "";
            // 
            // richTextBox37
            // 
            this.richTextBox37.Location = new System.Drawing.Point(370, 164);
            this.richTextBox37.Name = "richTextBox37";
            this.richTextBox37.Size = new System.Drawing.Size(75, 26);
            this.richTextBox37.TabIndex = 83;
            this.richTextBox37.Text = "";
            // 
            // richTextBox14
            // 
            this.richTextBox14.Location = new System.Drawing.Point(208, 196);
            this.richTextBox14.Name = "richTextBox14";
            this.richTextBox14.Size = new System.Drawing.Size(75, 26);
            this.richTextBox14.TabIndex = 48;
            this.richTextBox14.Text = "";
            // 
            // richTextBox38
            // 
            this.richTextBox38.Location = new System.Drawing.Point(370, 132);
            this.richTextBox38.Name = "richTextBox38";
            this.richTextBox38.Size = new System.Drawing.Size(75, 26);
            this.richTextBox38.TabIndex = 84;
            this.richTextBox38.Text = "";
            // 
            // richTextBox28
            // 
            this.richTextBox28.Location = new System.Drawing.Point(127, 356);
            this.richTextBox28.Name = "richTextBox28";
            this.richTextBox28.Size = new System.Drawing.Size(75, 26);
            this.richTextBox28.TabIndex = 35;
            this.richTextBox28.Text = "";
            // 
            // richTextBox39
            // 
            this.richTextBox39.Location = new System.Drawing.Point(370, 100);
            this.richTextBox39.Name = "richTextBox39";
            this.richTextBox39.Size = new System.Drawing.Size(75, 26);
            this.richTextBox39.TabIndex = 85;
            this.richTextBox39.Text = "";
            // 
            // richTextBox15
            // 
            this.richTextBox15.Location = new System.Drawing.Point(289, 196);
            this.richTextBox15.Name = "richTextBox15";
            this.richTextBox15.Size = new System.Drawing.Size(75, 26);
            this.richTextBox15.TabIndex = 56;
            this.richTextBox15.Text = "";
            // 
            // richTextBox40
            // 
            this.richTextBox40.Location = new System.Drawing.Point(370, 68);
            this.richTextBox40.Name = "richTextBox40";
            this.richTextBox40.Size = new System.Drawing.Size(75, 26);
            this.richTextBox40.TabIndex = 86;
            this.richTextBox40.Text = "";
            // 
            // richTextBox17
            // 
            this.richTextBox17.Location = new System.Drawing.Point(208, 228);
            this.richTextBox17.Name = "richTextBox17";
            this.richTextBox17.Size = new System.Drawing.Size(75, 26);
            this.richTextBox17.TabIndex = 49;
            this.richTextBox17.Text = "";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(318, 53);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(20, 12);
            this.label13.TabIndex = 76;
            this.label13.Text = "Rc";
            // 
            // richTextBox18
            // 
            this.richTextBox18.Location = new System.Drawing.Point(289, 228);
            this.richTextBox18.Name = "richTextBox18";
            this.richTextBox18.Size = new System.Drawing.Size(75, 26);
            this.richTextBox18.TabIndex = 58;
            this.richTextBox18.Text = "";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(233, 53);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(20, 12);
            this.label12.TabIndex = 75;
            this.label12.Text = "Rb";
            // 
            // richTextBox20
            // 
            this.richTextBox20.Location = new System.Drawing.Point(208, 260);
            this.richTextBox20.Name = "richTextBox20";
            this.richTextBox20.Size = new System.Drawing.Size(75, 26);
            this.richTextBox20.TabIndex = 47;
            this.richTextBox20.Text = "";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(157, 53);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(20, 12);
            this.label11.TabIndex = 74;
            this.label11.Text = "Ra";
            // 
            // richTextBox21
            // 
            this.richTextBox21.Location = new System.Drawing.Point(289, 260);
            this.richTextBox21.Name = "richTextBox21";
            this.richTextBox21.Size = new System.Drawing.Size(75, 26);
            this.richTextBox21.TabIndex = 59;
            this.richTextBox21.Text = "";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(66, 362);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(53, 12);
            this.label10.TabIndex = 72;
            this.label10.Text = "Robot 10";
            // 
            // richTextBox23
            // 
            this.richTextBox23.Location = new System.Drawing.Point(208, 292);
            this.richTextBox23.Name = "richTextBox23";
            this.richTextBox23.Size = new System.Drawing.Size(75, 26);
            this.richTextBox23.TabIndex = 46;
            this.richTextBox23.Text = "";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(66, 330);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(47, 12);
            this.label9.TabIndex = 71;
            this.label9.Text = "Robot 9";
            // 
            // richTextBox24
            // 
            this.richTextBox24.Location = new System.Drawing.Point(289, 292);
            this.richTextBox24.Name = "richTextBox24";
            this.richTextBox24.Size = new System.Drawing.Size(75, 26);
            this.richTextBox24.TabIndex = 61;
            this.richTextBox24.Text = "";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(66, 298);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(47, 12);
            this.label8.TabIndex = 70;
            this.label8.Text = "Robot 8";
            // 
            // richTextBox26
            // 
            this.richTextBox26.Location = new System.Drawing.Point(208, 324);
            this.richTextBox26.Name = "richTextBox26";
            this.richTextBox26.Size = new System.Drawing.Size(75, 26);
            this.richTextBox26.TabIndex = 45;
            this.richTextBox26.Text = "";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(66, 266);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(47, 12);
            this.label7.TabIndex = 69;
            this.label7.Text = "Robot 7";
            // 
            // richTextBox27
            // 
            this.richTextBox27.Location = new System.Drawing.Point(289, 324);
            this.richTextBox27.Name = "richTextBox27";
            this.richTextBox27.Size = new System.Drawing.Size(75, 26);
            this.richTextBox27.TabIndex = 62;
            this.richTextBox27.Text = "";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(66, 234);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(47, 12);
            this.label6.TabIndex = 68;
            this.label6.Text = "Robot 6";
            // 
            // richTextBox29
            // 
            this.richTextBox29.Location = new System.Drawing.Point(208, 356);
            this.richTextBox29.Name = "richTextBox29";
            this.richTextBox29.Size = new System.Drawing.Size(75, 26);
            this.richTextBox29.TabIndex = 44;
            this.richTextBox29.Text = "";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(66, 202);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(47, 12);
            this.label5.TabIndex = 67;
            this.label5.Text = "Robot 5";
            // 
            // richTextBox30
            // 
            this.richTextBox30.Location = new System.Drawing.Point(289, 356);
            this.richTextBox30.Name = "richTextBox30";
            this.richTextBox30.Size = new System.Drawing.Size(75, 26);
            this.richTextBox30.TabIndex = 63;
            this.richTextBox30.Text = "";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(66, 170);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(47, 12);
            this.label4.TabIndex = 73;
            this.label4.Text = "Robot 4";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(66, 74);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 12);
            this.label1.TabIndex = 64;
            this.label1.Text = "Robot 1";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(66, 138);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(47, 12);
            this.label3.TabIndex = 66;
            this.label3.Text = "Robot 3";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(66, 106);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 12);
            this.label2.TabIndex = 65;
            this.label2.Text = "Robot 2";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label16);
            this.groupBox3.Controls.Add(this.checkBox3);
            this.groupBox3.Controls.Add(this.richTextBox52);
            this.groupBox3.Controls.Add(this.checkBox2);
            this.groupBox3.Controls.Add(this.richTextBox53);
            this.groupBox3.Controls.Add(this.label17);
            this.groupBox3.Controls.Add(this.richTextBox54);
            this.groupBox3.Controls.Add(this.label30);
            this.groupBox3.Controls.Add(this.richTextBox55);
            this.groupBox3.Controls.Add(this.label29);
            this.groupBox3.Controls.Add(this.richTextBox56);
            this.groupBox3.Controls.Add(this.label28);
            this.groupBox3.Controls.Add(this.richTextBox57);
            this.groupBox3.Controls.Add(this.label27);
            this.groupBox3.Controls.Add(this.richTextBox58);
            this.groupBox3.Controls.Add(this.richTextBox101);
            this.groupBox3.Controls.Add(this.richTextBox59);
            this.groupBox3.Controls.Add(this.label26);
            this.groupBox3.Controls.Add(this.richTextBox60);
            this.groupBox3.Controls.Add(this.richTextBox100);
            this.groupBox3.Controls.Add(this.richTextBox61);
            this.groupBox3.Controls.Add(this.label25);
            this.groupBox3.Controls.Add(this.richTextBox62);
            this.groupBox3.Controls.Add(this.richTextBox99);
            this.groupBox3.Controls.Add(this.richTextBox63);
            this.groupBox3.Controls.Add(this.label24);
            this.groupBox3.Controls.Add(this.richTextBox64);
            this.groupBox3.Controls.Add(this.richTextBox98);
            this.groupBox3.Controls.Add(this.richTextBox65);
            this.groupBox3.Controls.Add(this.label23);
            this.groupBox3.Controls.Add(this.richTextBox66);
            this.groupBox3.Controls.Add(this.richTextBox97);
            this.groupBox3.Controls.Add(this.richTextBox67);
            this.groupBox3.Controls.Add(this.label22);
            this.groupBox3.Controls.Add(this.richTextBox68);
            this.groupBox3.Controls.Add(this.richTextBox96);
            this.groupBox3.Controls.Add(this.richTextBox69);
            this.groupBox3.Controls.Add(this.label21);
            this.groupBox3.Controls.Add(this.richTextBox70);
            this.groupBox3.Controls.Add(this.richTextBox95);
            this.groupBox3.Controls.Add(this.richTextBox71);
            this.groupBox3.Controls.Add(this.label20);
            this.groupBox3.Controls.Add(this.richTextBox72);
            this.groupBox3.Controls.Add(this.richTextBox94);
            this.groupBox3.Controls.Add(this.label19);
            this.groupBox3.Controls.Add(this.richTextBox73);
            this.groupBox3.Controls.Add(this.richTextBox93);
            this.groupBox3.Controls.Add(this.richTextBox74);
            this.groupBox3.Controls.Add(this.label18);
            this.groupBox3.Controls.Add(this.richTextBox75);
            this.groupBox3.Controls.Add(this.richTextBox92);
            this.groupBox3.Controls.Add(this.richTextBox76);
            this.groupBox3.Controls.Add(this.richTextBox91);
            this.groupBox3.Controls.Add(this.richTextBox77);
            this.groupBox3.Controls.Add(this.richTextBox90);
            this.groupBox3.Controls.Add(this.richTextBox78);
            this.groupBox3.Controls.Add(this.richTextBox89);
            this.groupBox3.Controls.Add(this.richTextBox79);
            this.groupBox3.Controls.Add(this.richTextBox88);
            this.groupBox3.Controls.Add(this.richTextBox80);
            this.groupBox3.Controls.Add(this.richTextBox87);
            this.groupBox3.Controls.Add(this.richTextBox81);
            this.groupBox3.Controls.Add(this.richTextBox86);
            this.groupBox3.Controls.Add(this.richTextBox82);
            this.groupBox3.Controls.Add(this.richTextBox85);
            this.groupBox3.Controls.Add(this.richTextBox83);
            this.groupBox3.Controls.Add(this.richTextBox84);
            this.groupBox3.Location = new System.Drawing.Point(14, 474);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(1042, 502);
            this.groupBox3.TabIndex = 9;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = " ";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(898, 86);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(61, 12);
            this.label16.TabIndex = 163;
            this.label16.Text = "Position y";
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Location = new System.Drawing.Point(56, 101);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(115, 16);
            this.checkBox3.TabIndex = 10;
            this.checkBox3.Text = "Moving Average";
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // richTextBox52
            // 
            this.richTextBox52.Location = new System.Drawing.Point(811, 229);
            this.richTextBox52.Name = "richTextBox52";
            this.richTextBox52.Size = new System.Drawing.Size(75, 26);
            this.richTextBox52.TabIndex = 147;
            this.richTextBox52.Text = "";
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(56, 133);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(67, 16);
            this.checkBox2.TabIndex = 0;
            this.checkBox2.Text = "Kalman";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // richTextBox53
            // 
            this.richTextBox53.Location = new System.Drawing.Point(892, 389);
            this.richTextBox53.Name = "richTextBox53";
            this.richTextBox53.Size = new System.Drawing.Size(75, 26);
            this.richTextBox53.TabIndex = 153;
            this.richTextBox53.Text = "";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(817, 86);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(61, 12);
            this.label17.TabIndex = 152;
            this.label17.Text = "Position x";
            // 
            // richTextBox54
            // 
            this.richTextBox54.Location = new System.Drawing.Point(568, 101);
            this.richTextBox54.Name = "richTextBox54";
            this.richTextBox54.Size = new System.Drawing.Size(75, 26);
            this.richTextBox54.TabIndex = 99;
            this.richTextBox54.Text = "";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(507, 139);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(47, 12);
            this.label30.TabIndex = 130;
            this.label30.Text = "Robot 2";
            // 
            // richTextBox55
            // 
            this.richTextBox55.Location = new System.Drawing.Point(892, 357);
            this.richTextBox55.Name = "richTextBox55";
            this.richTextBox55.Size = new System.Drawing.Size(75, 26);
            this.richTextBox55.TabIndex = 154;
            this.richTextBox55.Text = "";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(507, 171);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(47, 12);
            this.label29.TabIndex = 131;
            this.label29.Text = "Robot 3";
            // 
            // richTextBox56
            // 
            this.richTextBox56.Location = new System.Drawing.Point(649, 101);
            this.richTextBox56.Name = "richTextBox56";
            this.richTextBox56.Size = new System.Drawing.Size(75, 26);
            this.richTextBox56.TabIndex = 118;
            this.richTextBox56.Text = "";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(507, 107);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(47, 12);
            this.label28.TabIndex = 129;
            this.label28.Text = "Robot 1";
            // 
            // richTextBox57
            // 
            this.richTextBox57.Location = new System.Drawing.Point(892, 325);
            this.richTextBox57.Name = "richTextBox57";
            this.richTextBox57.Size = new System.Drawing.Size(75, 26);
            this.richTextBox57.TabIndex = 155;
            this.richTextBox57.Text = "";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(507, 203);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(47, 12);
            this.label27.TabIndex = 138;
            this.label27.Text = "Robot 4";
            // 
            // richTextBox58
            // 
            this.richTextBox58.Location = new System.Drawing.Point(568, 133);
            this.richTextBox58.Name = "richTextBox58";
            this.richTextBox58.Size = new System.Drawing.Size(75, 26);
            this.richTextBox58.TabIndex = 108;
            this.richTextBox58.Text = "";
            // 
            // richTextBox101
            // 
            this.richTextBox101.Location = new System.Drawing.Point(730, 389);
            this.richTextBox101.Name = "richTextBox101";
            this.richTextBox101.Size = new System.Drawing.Size(75, 26);
            this.richTextBox101.TabIndex = 128;
            this.richTextBox101.Text = "";
            // 
            // richTextBox59
            // 
            this.richTextBox59.Location = new System.Drawing.Point(892, 293);
            this.richTextBox59.Name = "richTextBox59";
            this.richTextBox59.Size = new System.Drawing.Size(75, 26);
            this.richTextBox59.TabIndex = 156;
            this.richTextBox59.Text = "";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(507, 235);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(47, 12);
            this.label26.TabIndex = 132;
            this.label26.Text = "Robot 5";
            // 
            // richTextBox60
            // 
            this.richTextBox60.Location = new System.Drawing.Point(730, 101);
            this.richTextBox60.Name = "richTextBox60";
            this.richTextBox60.Size = new System.Drawing.Size(75, 26);
            this.richTextBox60.TabIndex = 120;
            this.richTextBox60.Text = "";
            // 
            // richTextBox100
            // 
            this.richTextBox100.Location = new System.Drawing.Point(649, 389);
            this.richTextBox100.Name = "richTextBox100";
            this.richTextBox100.Size = new System.Drawing.Size(75, 26);
            this.richTextBox100.TabIndex = 109;
            this.richTextBox100.Text = "";
            // 
            // richTextBox61
            // 
            this.richTextBox61.Location = new System.Drawing.Point(892, 261);
            this.richTextBox61.Name = "richTextBox61";
            this.richTextBox61.Size = new System.Drawing.Size(75, 26);
            this.richTextBox61.TabIndex = 157;
            this.richTextBox61.Text = "";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(507, 267);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(47, 12);
            this.label25.TabIndex = 133;
            this.label25.Text = "Robot 6";
            // 
            // richTextBox62
            // 
            this.richTextBox62.Location = new System.Drawing.Point(568, 165);
            this.richTextBox62.Name = "richTextBox62";
            this.richTextBox62.Size = new System.Drawing.Size(75, 26);
            this.richTextBox62.TabIndex = 107;
            this.richTextBox62.Text = "";
            // 
            // richTextBox99
            // 
            this.richTextBox99.Location = new System.Drawing.Point(730, 357);
            this.richTextBox99.Name = "richTextBox99";
            this.richTextBox99.Size = new System.Drawing.Size(75, 26);
            this.richTextBox99.TabIndex = 127;
            this.richTextBox99.Text = "";
            // 
            // richTextBox63
            // 
            this.richTextBox63.Location = new System.Drawing.Point(892, 229);
            this.richTextBox63.Name = "richTextBox63";
            this.richTextBox63.Size = new System.Drawing.Size(75, 26);
            this.richTextBox63.TabIndex = 158;
            this.richTextBox63.Text = "";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(507, 299);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(47, 12);
            this.label24.TabIndex = 134;
            this.label24.Text = "Robot 7";
            // 
            // richTextBox64
            // 
            this.richTextBox64.Location = new System.Drawing.Point(649, 133);
            this.richTextBox64.Name = "richTextBox64";
            this.richTextBox64.Size = new System.Drawing.Size(75, 26);
            this.richTextBox64.TabIndex = 116;
            this.richTextBox64.Text = "";
            // 
            // richTextBox98
            // 
            this.richTextBox98.Location = new System.Drawing.Point(649, 357);
            this.richTextBox98.Name = "richTextBox98";
            this.richTextBox98.Size = new System.Drawing.Size(75, 26);
            this.richTextBox98.TabIndex = 110;
            this.richTextBox98.Text = "";
            // 
            // richTextBox65
            // 
            this.richTextBox65.Location = new System.Drawing.Point(892, 197);
            this.richTextBox65.Name = "richTextBox65";
            this.richTextBox65.Size = new System.Drawing.Size(75, 26);
            this.richTextBox65.TabIndex = 159;
            this.richTextBox65.Text = "";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(507, 331);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(47, 12);
            this.label23.TabIndex = 135;
            this.label23.Text = "Robot 8";
            // 
            // richTextBox66
            // 
            this.richTextBox66.Location = new System.Drawing.Point(568, 197);
            this.richTextBox66.Name = "richTextBox66";
            this.richTextBox66.Size = new System.Drawing.Size(75, 26);
            this.richTextBox66.TabIndex = 106;
            this.richTextBox66.Text = "";
            // 
            // richTextBox97
            // 
            this.richTextBox97.Location = new System.Drawing.Point(730, 325);
            this.richTextBox97.Name = "richTextBox97";
            this.richTextBox97.Size = new System.Drawing.Size(75, 26);
            this.richTextBox97.TabIndex = 126;
            this.richTextBox97.Text = "";
            // 
            // richTextBox67
            // 
            this.richTextBox67.Location = new System.Drawing.Point(892, 165);
            this.richTextBox67.Name = "richTextBox67";
            this.richTextBox67.Size = new System.Drawing.Size(75, 26);
            this.richTextBox67.TabIndex = 160;
            this.richTextBox67.Text = "";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(507, 363);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(47, 12);
            this.label22.TabIndex = 136;
            this.label22.Text = "Robot 9";
            // 
            // richTextBox68
            // 
            this.richTextBox68.Location = new System.Drawing.Point(730, 133);
            this.richTextBox68.Name = "richTextBox68";
            this.richTextBox68.Size = new System.Drawing.Size(75, 26);
            this.richTextBox68.TabIndex = 122;
            this.richTextBox68.Text = "";
            // 
            // richTextBox96
            // 
            this.richTextBox96.Location = new System.Drawing.Point(649, 325);
            this.richTextBox96.Name = "richTextBox96";
            this.richTextBox96.Size = new System.Drawing.Size(75, 26);
            this.richTextBox96.TabIndex = 111;
            this.richTextBox96.Text = "";
            // 
            // richTextBox69
            // 
            this.richTextBox69.Location = new System.Drawing.Point(892, 133);
            this.richTextBox69.Name = "richTextBox69";
            this.richTextBox69.Size = new System.Drawing.Size(75, 26);
            this.richTextBox69.TabIndex = 161;
            this.richTextBox69.Text = "";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(507, 395);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(53, 12);
            this.label21.TabIndex = 137;
            this.label21.Text = "Robot 10";
            // 
            // richTextBox70
            // 
            this.richTextBox70.Location = new System.Drawing.Point(568, 229);
            this.richTextBox70.Name = "richTextBox70";
            this.richTextBox70.Size = new System.Drawing.Size(75, 26);
            this.richTextBox70.TabIndex = 104;
            this.richTextBox70.Text = "";
            // 
            // richTextBox95
            // 
            this.richTextBox95.Location = new System.Drawing.Point(730, 293);
            this.richTextBox95.Name = "richTextBox95";
            this.richTextBox95.Size = new System.Drawing.Size(75, 26);
            this.richTextBox95.TabIndex = 124;
            this.richTextBox95.Text = "";
            // 
            // richTextBox71
            // 
            this.richTextBox71.Location = new System.Drawing.Point(892, 101);
            this.richTextBox71.Name = "richTextBox71";
            this.richTextBox71.Size = new System.Drawing.Size(75, 26);
            this.richTextBox71.TabIndex = 162;
            this.richTextBox71.Text = "";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(598, 86);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(20, 12);
            this.label20.TabIndex = 139;
            this.label20.Text = "Ra";
            // 
            // richTextBox72
            // 
            this.richTextBox72.Location = new System.Drawing.Point(649, 165);
            this.richTextBox72.Name = "richTextBox72";
            this.richTextBox72.Size = new System.Drawing.Size(75, 26);
            this.richTextBox72.TabIndex = 117;
            this.richTextBox72.Text = "";
            // 
            // richTextBox94
            // 
            this.richTextBox94.Location = new System.Drawing.Point(649, 293);
            this.richTextBox94.Name = "richTextBox94";
            this.richTextBox94.Size = new System.Drawing.Size(75, 26);
            this.richTextBox94.TabIndex = 112;
            this.richTextBox94.Text = "";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(674, 86);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(20, 12);
            this.label19.TabIndex = 140;
            this.label19.Text = "Rb";
            // 
            // richTextBox73
            // 
            this.richTextBox73.Location = new System.Drawing.Point(568, 261);
            this.richTextBox73.Name = "richTextBox73";
            this.richTextBox73.Size = new System.Drawing.Size(75, 26);
            this.richTextBox73.TabIndex = 103;
            this.richTextBox73.Text = "";
            // 
            // richTextBox93
            // 
            this.richTextBox93.Location = new System.Drawing.Point(730, 261);
            this.richTextBox93.Name = "richTextBox93";
            this.richTextBox93.Size = new System.Drawing.Size(75, 26);
            this.richTextBox93.TabIndex = 123;
            this.richTextBox93.Text = "";
            // 
            // richTextBox74
            // 
            this.richTextBox74.Location = new System.Drawing.Point(811, 389);
            this.richTextBox74.Name = "richTextBox74";
            this.richTextBox74.Size = new System.Drawing.Size(75, 26);
            this.richTextBox74.TabIndex = 142;
            this.richTextBox74.Text = "";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(759, 86);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(20, 12);
            this.label18.TabIndex = 141;
            this.label18.Text = "Rc";
            // 
            // richTextBox75
            // 
            this.richTextBox75.Location = new System.Drawing.Point(730, 165);
            this.richTextBox75.Name = "richTextBox75";
            this.richTextBox75.Size = new System.Drawing.Size(75, 26);
            this.richTextBox75.TabIndex = 125;
            this.richTextBox75.Text = "";
            // 
            // richTextBox92
            // 
            this.richTextBox92.Location = new System.Drawing.Point(649, 261);
            this.richTextBox92.Name = "richTextBox92";
            this.richTextBox92.Size = new System.Drawing.Size(75, 26);
            this.richTextBox92.TabIndex = 114;
            this.richTextBox92.Text = "";
            // 
            // richTextBox76
            // 
            this.richTextBox76.Location = new System.Drawing.Point(811, 357);
            this.richTextBox76.Name = "richTextBox76";
            this.richTextBox76.Size = new System.Drawing.Size(75, 26);
            this.richTextBox76.TabIndex = 143;
            this.richTextBox76.Text = "";
            // 
            // richTextBox91
            // 
            this.richTextBox91.Location = new System.Drawing.Point(811, 101);
            this.richTextBox91.Name = "richTextBox91";
            this.richTextBox91.Size = new System.Drawing.Size(75, 26);
            this.richTextBox91.TabIndex = 151;
            this.richTextBox91.Text = "";
            // 
            // richTextBox77
            // 
            this.richTextBox77.Location = new System.Drawing.Point(568, 293);
            this.richTextBox77.Name = "richTextBox77";
            this.richTextBox77.Size = new System.Drawing.Size(75, 26);
            this.richTextBox77.TabIndex = 102;
            this.richTextBox77.Text = "";
            // 
            // richTextBox90
            // 
            this.richTextBox90.Location = new System.Drawing.Point(730, 229);
            this.richTextBox90.Name = "richTextBox90";
            this.richTextBox90.Size = new System.Drawing.Size(75, 26);
            this.richTextBox90.TabIndex = 121;
            this.richTextBox90.Text = "";
            // 
            // richTextBox78
            // 
            this.richTextBox78.Location = new System.Drawing.Point(811, 325);
            this.richTextBox78.Name = "richTextBox78";
            this.richTextBox78.Size = new System.Drawing.Size(75, 26);
            this.richTextBox78.TabIndex = 144;
            this.richTextBox78.Text = "";
            // 
            // richTextBox89
            // 
            this.richTextBox89.Location = new System.Drawing.Point(811, 133);
            this.richTextBox89.Name = "richTextBox89";
            this.richTextBox89.Size = new System.Drawing.Size(75, 26);
            this.richTextBox89.TabIndex = 150;
            this.richTextBox89.Text = "";
            // 
            // richTextBox79
            // 
            this.richTextBox79.Location = new System.Drawing.Point(649, 197);
            this.richTextBox79.Name = "richTextBox79";
            this.richTextBox79.Size = new System.Drawing.Size(75, 26);
            this.richTextBox79.TabIndex = 115;
            this.richTextBox79.Text = "";
            // 
            // richTextBox88
            // 
            this.richTextBox88.Location = new System.Drawing.Point(568, 389);
            this.richTextBox88.Name = "richTextBox88";
            this.richTextBox88.Size = new System.Drawing.Size(75, 26);
            this.richTextBox88.TabIndex = 100;
            this.richTextBox88.Text = "";
            // 
            // richTextBox80
            // 
            this.richTextBox80.Location = new System.Drawing.Point(811, 293);
            this.richTextBox80.Name = "richTextBox80";
            this.richTextBox80.Size = new System.Drawing.Size(75, 26);
            this.richTextBox80.TabIndex = 145;
            this.richTextBox80.Text = "";
            // 
            // richTextBox87
            // 
            this.richTextBox87.Location = new System.Drawing.Point(811, 165);
            this.richTextBox87.Name = "richTextBox87";
            this.richTextBox87.Size = new System.Drawing.Size(75, 26);
            this.richTextBox87.TabIndex = 149;
            this.richTextBox87.Text = "";
            // 
            // richTextBox81
            // 
            this.richTextBox81.Location = new System.Drawing.Point(568, 325);
            this.richTextBox81.Name = "richTextBox81";
            this.richTextBox81.Size = new System.Drawing.Size(75, 26);
            this.richTextBox81.TabIndex = 101;
            this.richTextBox81.Text = "";
            // 
            // richTextBox86
            // 
            this.richTextBox86.Location = new System.Drawing.Point(649, 229);
            this.richTextBox86.Name = "richTextBox86";
            this.richTextBox86.Size = new System.Drawing.Size(75, 26);
            this.richTextBox86.TabIndex = 113;
            this.richTextBox86.Text = "";
            // 
            // richTextBox82
            // 
            this.richTextBox82.Location = new System.Drawing.Point(811, 261);
            this.richTextBox82.Name = "richTextBox82";
            this.richTextBox82.Size = new System.Drawing.Size(75, 26);
            this.richTextBox82.TabIndex = 146;
            this.richTextBox82.Text = "";
            // 
            // richTextBox85
            // 
            this.richTextBox85.Location = new System.Drawing.Point(811, 197);
            this.richTextBox85.Name = "richTextBox85";
            this.richTextBox85.Size = new System.Drawing.Size(75, 26);
            this.richTextBox85.TabIndex = 148;
            this.richTextBox85.Text = "";
            // 
            // richTextBox83
            // 
            this.richTextBox83.Location = new System.Drawing.Point(730, 197);
            this.richTextBox83.Name = "richTextBox83";
            this.richTextBox83.Size = new System.Drawing.Size(75, 26);
            this.richTextBox83.TabIndex = 119;
            this.richTextBox83.Text = "";
            // 
            // richTextBox84
            // 
            this.richTextBox84.Location = new System.Drawing.Point(568, 357);
            this.richTextBox84.Name = "richTextBox84";
            this.richTextBox84.Size = new System.Drawing.Size(75, 26);
            this.richTextBox84.TabIndex = 105;
            this.richTextBox84.Text = "";
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // groupBox4
            // 
            this.groupBox4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("groupBox4.BackgroundImage")));
            this.groupBox4.Controls.Add(this.checkBox5);
            this.groupBox4.Controls.Add(this.checkBox4);
            this.groupBox4.Location = new System.Drawing.Point(1220, 251);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(465, 465);
            this.groupBox4.TabIndex = 11;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "움직임 시각화";
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.BackColor = System.Drawing.Color.RosyBrown;
            this.checkBox5.Location = new System.Drawing.Point(226, 223);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(65, 16);
            this.checkBox5.TabIndex = 13;
            this.checkBox5.Text = "Filtered";
            this.checkBox5.UseVisualStyleBackColor = false;
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(1217, 223);
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(120, 21);
            this.numericUpDown1.TabIndex = 1;
            // 
            // checkBox6
            // 
            this.checkBox6.AutoSize = true;
            this.checkBox6.Location = new System.Drawing.Point(1343, 225);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(15, 14);
            this.checkBox6.TabIndex = 12;
            this.checkBox6.UseVisualStyleBackColor = true;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(1217, 193);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 21);
            this.textBox2.TabIndex = 13;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(1323, 192);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 14;
            this.button2.Text = "감도 설정";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.BackColor = System.Drawing.SystemColors.Info;
            this.checkBox4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.checkBox4.ImageAlign = System.Drawing.ContentAlignment.TopRight;
            this.checkBox4.Location = new System.Drawing.Point(225, 223);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(50, 16);
            this.checkBox4.TabIndex = 12;
            this.checkBox4.Text = "Pure";
            this.checkBox4.UseVisualStyleBackColor = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1894, 1008);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.checkBox6);
            this.Controls.Add(this.numericUpDown1);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "PC 통합 매니지먼트";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.RichTextBox richTextBox36;
        private System.Windows.Forms.RichTextBox richTextBox41;
        private System.Windows.Forms.RichTextBox richTextBox51;
        private System.Windows.Forms.RichTextBox richTextBox42;
        private System.Windows.Forms.RichTextBox richTextBox2;
        private System.Windows.Forms.RichTextBox richTextBox43;
        private System.Windows.Forms.RichTextBox richTextBox4;
        private System.Windows.Forms.RichTextBox richTextBox44;
        private System.Windows.Forms.RichTextBox richTextBox3;
        private System.Windows.Forms.RichTextBox richTextBox45;
        private System.Windows.Forms.RichTextBox richTextBox7;
        private System.Windows.Forms.RichTextBox richTextBox46;
        private System.Windows.Forms.RichTextBox richTextBox5;
        private System.Windows.Forms.RichTextBox richTextBox47;
        private System.Windows.Forms.RichTextBox richTextBox10;
        private System.Windows.Forms.RichTextBox richTextBox48;
        private System.Windows.Forms.RichTextBox richTextBox6;
        private System.Windows.Forms.RichTextBox richTextBox49;
        private System.Windows.Forms.RichTextBox richTextBox13;
        private System.Windows.Forms.RichTextBox richTextBox50;
        private System.Windows.Forms.RichTextBox richTextBox8;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.RichTextBox richTextBox16;
        private System.Windows.Forms.RichTextBox richTextBox31;
        private System.Windows.Forms.RichTextBox richTextBox9;
        private System.Windows.Forms.RichTextBox richTextBox32;
        private System.Windows.Forms.RichTextBox richTextBox19;
        private System.Windows.Forms.RichTextBox richTextBox33;
        private System.Windows.Forms.RichTextBox richTextBox11;
        private System.Windows.Forms.RichTextBox richTextBox34;
        private System.Windows.Forms.RichTextBox richTextBox22;
        private System.Windows.Forms.RichTextBox richTextBox35;
        private System.Windows.Forms.RichTextBox richTextBox12;
        private System.Windows.Forms.RichTextBox richTextBox25;
        private System.Windows.Forms.RichTextBox richTextBox37;
        private System.Windows.Forms.RichTextBox richTextBox14;
        private System.Windows.Forms.RichTextBox richTextBox38;
        private System.Windows.Forms.RichTextBox richTextBox28;
        private System.Windows.Forms.RichTextBox richTextBox39;
        private System.Windows.Forms.RichTextBox richTextBox15;
        private System.Windows.Forms.RichTextBox richTextBox40;
        private System.Windows.Forms.RichTextBox richTextBox17;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.RichTextBox richTextBox18;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.RichTextBox richTextBox20;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.RichTextBox richTextBox21;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.RichTextBox richTextBox23;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.RichTextBox richTextBox24;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.RichTextBox richTextBox26;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.RichTextBox richTextBox27;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.RichTextBox richTextBox29;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.RichTextBox richTextBox30;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.RichTextBox richTextBox52;
        private System.Windows.Forms.RichTextBox richTextBox53;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.RichTextBox richTextBox54;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.RichTextBox richTextBox55;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.RichTextBox richTextBox56;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.RichTextBox richTextBox57;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.RichTextBox richTextBox58;
        private System.Windows.Forms.RichTextBox richTextBox101;
        private System.Windows.Forms.RichTextBox richTextBox59;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.RichTextBox richTextBox60;
        private System.Windows.Forms.RichTextBox richTextBox100;
        private System.Windows.Forms.RichTextBox richTextBox61;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.RichTextBox richTextBox62;
        private System.Windows.Forms.RichTextBox richTextBox99;
        private System.Windows.Forms.RichTextBox richTextBox63;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.RichTextBox richTextBox64;
        private System.Windows.Forms.RichTextBox richTextBox98;
        private System.Windows.Forms.RichTextBox richTextBox65;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.RichTextBox richTextBox66;
        private System.Windows.Forms.RichTextBox richTextBox97;
        private System.Windows.Forms.RichTextBox richTextBox67;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.RichTextBox richTextBox68;
        private System.Windows.Forms.RichTextBox richTextBox96;
        private System.Windows.Forms.RichTextBox richTextBox69;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.RichTextBox richTextBox70;
        private System.Windows.Forms.RichTextBox richTextBox95;
        private System.Windows.Forms.RichTextBox richTextBox71;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.RichTextBox richTextBox72;
        private System.Windows.Forms.RichTextBox richTextBox94;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.RichTextBox richTextBox73;
        private System.Windows.Forms.RichTextBox richTextBox93;
        private System.Windows.Forms.RichTextBox richTextBox74;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.RichTextBox richTextBox75;
        private System.Windows.Forms.RichTextBox richTextBox92;
        private System.Windows.Forms.RichTextBox richTextBox76;
        private System.Windows.Forms.RichTextBox richTextBox91;
        private System.Windows.Forms.RichTextBox richTextBox77;
        private System.Windows.Forms.RichTextBox richTextBox90;
        private System.Windows.Forms.RichTextBox richTextBox78;
        private System.Windows.Forms.RichTextBox richTextBox89;
        private System.Windows.Forms.RichTextBox richTextBox79;
        private System.Windows.Forms.RichTextBox richTextBox88;
        private System.Windows.Forms.RichTextBox richTextBox80;
        private System.Windows.Forms.RichTextBox richTextBox87;
        private System.Windows.Forms.RichTextBox richTextBox81;
        private System.Windows.Forms.RichTextBox richTextBox86;
        private System.Windows.Forms.RichTextBox richTextBox82;
        private System.Windows.Forms.RichTextBox richTextBox85;
        private System.Windows.Forms.RichTextBox richTextBox83;
        private System.Windows.Forms.RichTextBox richTextBox84;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.CheckBox checkBox6;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.CheckBox checkBox4;
    }
}

